<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

final class AccessController extends Controller
{
    public function resetPassword(Request $request, int $id): JsonResponse
    {
        $data = $request->validate([
            'password' => 'required|string|min:8|max:128|confirmed',
            'reason' => 'required|string|max:500',
        ]);
        abort_if(trim($data['reason']) === '', 422, 'Enter a reason for resetting the password.');
        return DB::transaction(function () use ($request, $id, $data) {
            $user = DB::table('users')->where('id', $id)->lockForUpdate()->first();
            abort_unless($user, 404, 'User not found.');
            DB::table('users')->where('id', $id)->update(['password' => Hash::make($data['password']), 'updated_at' => now()]);
            $sessions = DB::table('access_tokens')->where('user_id', $id);
            if ((int) $request->attributes->get('auth_user')->id === $id) {
                $sessions->where('token_hash', '!=', hash('sha256', $request->bearerToken()));
            }
            $sessions->delete();
            DB::table('audit_logs')->insert([
                'event' => 'user.password_reset', 'entity_type' => 'user', 'entity_id' => $id,
                'payload' => json_encode(['actor_id' => $request->attributes->get('auth_user')->id, 'reason' => trim($data['reason'])]),
                'created_at' => now(),
            ]);
            return response()->json(['message' => 'Password updated. Other active sessions have been signed out.']);
        });
    }

    public function index(): JsonResponse
    {
        $users = DB::table("users as u")
            ->join("roles as r", "r.id", "=", "u.role_id")
            ->leftJoin("sales_representatives as sr", "sr.id", "=", "u.sales_rep_id")
            ->select(
                "u.id",
                "u.role_id",
                "u.sales_rep_id",
                "u.name",
                "u.email",
                "u.active",
                "u.created_at",
                "r.name as role_name",
                "r.code as role_code",
                "sr.name as sales_rep_name",
            )
            ->orderBy("u.name")
            ->get();
        $permissions = DB::table("permissions")->orderBy("code")->get();
        $rolePermissions = DB::table("role_permissions")->get()->groupBy("role_id");
        $roles = DB::table("roles")
            ->orderBy("name")
            ->get()
            ->map(function ($role) use ($rolePermissions) {
                $role->permission_ids = $rolePermissions
                    ->get($role->id, collect())
                    ->pluck("permission_id")
                    ->values();
                return $role;
            });
        $sales_reps = DB::table("sales_representatives")
            ->where("status", "active")
            ->orderBy("name")
            ->get();
        return response()->json(compact("users", "roles", "permissions", "sales_reps"));
    }

    public function storeUser(Request $request): JsonResponse
    {
        $data = $request->validate([
            "name" => "required|string|max:160",
            "email" => "required|email|max:160|unique:users,email",
            "role_id" => "required|exists:roles,id",
            "sales_rep_id" => "nullable|exists:sales_representatives,id|unique:users,sales_rep_id",
            "password" => "required|string|min:8",
            "active" => "required|boolean",
        ]);
        abort_if(
            DB::table("roles")->where("id", $data["role_id"])->value("code") === "sales_person" &&
                empty($data["sales_rep_id"]),
            422,
            "A salesperson login must be linked to a salesperson profile.",
        );
        $data["password"] = Hash::make($data["password"]);
        $data["created_at"] = now();
        $data["updated_at"] = now();
        $id = DB::table("users")->insertGetId($data);
        $user = (array) DB::table("users")->find($id);
        unset($user['password'], $user['remember_token']);
        return response()->json($user, 201);
    }

    public function updateUser(Request $request, int $id): JsonResponse
    {
        $data = $request->validate([
            "name" => "required|string|max:160",
            "email" => [
                "required",
                "email",
                "max:160",
                Rule::unique("users", "email")->ignore($id),
            ],
            "role_id" => "required|exists:roles,id",
            "sales_rep_id" => [
                "nullable",
                "exists:sales_representatives,id",
                Rule::unique("users", "sales_rep_id")->ignore($id),
            ],
            "password" => "nullable|string|min:8",
            "active" => "required|boolean",
        ]);
        abort_if(
            DB::table("roles")->where("id", $data["role_id"])->value("code") === "sales_person" &&
                empty($data["sales_rep_id"]),
            422,
            "A salesperson login must be linked to a salesperson profile.",
        );
        $current = (int) $request->attributes->get("auth_user")->id;
        abort_if(
            $current === $id && !$data["active"],
            422,
            "You cannot deactivate your own account.",
        );
        if (empty($data["password"])) {
            unset($data["password"]);
        } else {
            $data["password"] = Hash::make($data["password"]);
        }
        $data["updated_at"] = now();
        DB::table("users")->where("id", $id)->update($data);
        $user = (array) DB::table("users")->find($id);
        unset($user['password'], $user['remember_token']);
        return response()->json($user);
    }

    public function deleteUser(Request $request, int $id): JsonResponse
    {
        abort_if(
            (int) $request->attributes->get("auth_user")->id === $id,
            422,
            "You cannot delete your own account.",
        );
        abort_unless(DB::table("users")->where("id", $id)->delete(), 404, "User not found.");
        return response()->json(["message" => "User deleted."]);
    }

    public function storeRole(Request $request): JsonResponse
    {
        $data = $this->roleData($request);
        $id = DB::transaction(function () use ($data) {
            $id = DB::table("roles")->insertGetId([
                "code" => $data["code"],
                "name" => $data["name"],
                "created_at" => now(),
                "updated_at" => now(),
            ]);
            $this->syncPermissions($id, $data["permission_ids"]);
            return $id;
        });
        return response()->json(DB::table("roles")->find($id), 201);
    }

    public function updateRole(Request $request, int $id): JsonResponse
    {
        $role = DB::table("roles")->find($id);
        abort_unless($role, 404, "Role not found.");
        $data = $this->roleData($request, $id);
        DB::transaction(function () use ($data, $id, $role) {
            DB::table("roles")
                ->where("id", $id)
                ->update([
                    "code" => $role->code === "administrator" ? "administrator" : $data["code"],
                    "name" => $data["name"],
                    "updated_at" => now(),
                ]);
            $permissionIds = $data["permission_ids"];
            if ($role->code === "administrator") {
                $adminPermission = DB::table("permissions")
                    ->where("code", "admin.manage")
                    ->value("id");
                if ($adminPermission) {
                    $permissionIds[] = $adminPermission;
                }
            }
            $this->syncPermissions($id, $permissionIds);
        });
        return response()->json(DB::table("roles")->find($id));
    }

    public function deleteRole(int $id): JsonResponse
    {
        $role = DB::table("roles")->find($id);
        abort_unless($role, 404, "Role not found.");
        abort_if($role->code === "administrator", 422, "The Administrator role cannot be deleted.");
        abort_if(
            DB::table("users")->where("role_id", $id)->exists(),
            422,
            "Move users to another role before deleting this role.",
        );
        DB::table("roles")->where("id", $id)->delete();
        return response()->json(["message" => "Role deleted."]);
    }

    private function roleData(Request $request, ?int $id = null): array
    {
        return $request->validate([
            "code" => [
                "required",
                "alpha_dash",
                "max:40",
                Rule::unique("roles", "code")->ignore($id),
            ],
            "name" => "required|string|max:160",
            "permission_ids" => "required|array",
            "permission_ids.*" => "integer|exists:permissions,id",
        ]);
    }
    private function syncPermissions(int $roleId, array $permissionIds): void
    {
        DB::table("role_permissions")->where("role_id", $roleId)->delete();
        foreach (array_unique($permissionIds) as $permissionId) {
            DB::table("role_permissions")->insert([
                "role_id" => $roleId,
                "permission_id" => $permissionId,
            ]);
        }
    }
}
